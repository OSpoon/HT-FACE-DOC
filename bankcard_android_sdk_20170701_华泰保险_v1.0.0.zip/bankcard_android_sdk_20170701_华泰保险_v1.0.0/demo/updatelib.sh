#!/bin/bash

if [ "$#" -ne 3 ];then
    echo "updatelib.sh sodir_path jarfile_path  model_path"
    exit 1
fi

DEMODIR=$(dirname "$0")
LIBDIR=BankCardLib

rm -fv $DEMODIR/${LIBDIR}/libs/bankcard*.jar

#copy so file

[ ! -e $1/armeabi-v7a ] || cp -rp $1/armeabi-v7a $DEMODIR/${LIBDIR}/libs/
[ ! -e $1/arm64-v8a ] || cp -rp $1/arm64-v8a $DEMODIR/${LIBDIR}/libs/
[ ! -e $1/x86 ] || cp -rp $1/x86 $DEMODIR/${LIBDIR}/libs/

#copy jar file
[ ! -e $2 ] || cp -rp $2 $DEMODIR/${LIBDIR}/libs/ 

#copy model
[ ! -e $3 ] || cp -rp $3 $DEMODIR/${LIBDIR}/res/raw/bankcardmodel

